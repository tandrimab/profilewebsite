export const activities = [
  {
    'text': 'ACM IMC 2018 Shadow PC member'
  }
]