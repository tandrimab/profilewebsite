export const teachings = [
    {
        "subject": "Future Internet",
        "semesters": [ "Spring 2019, 2020"],
        "institute": "ETH Zürich",
        "place": "Zürich, Switzerland",
        "image": "future-internet.jpg"
    },
    {
        "subject": "Computer Networks",
        "semesters": [ "Spring 2019, 2020" ],
        "institute": "ETH Zürich",
        "place": "Zürich, Switzerland",
        "image": "computer-networking.jpg"
    },
    {
        "subject": "Advanced Computer Networks",
        "semesters": [ "Spring 2017, 2018" ],
        "institute": "ETH Zürich",
        "place": "Zürich, Switzerland",
        "image": "advanced-computer-networks.jpg"
    },
    {
        "subject": "Big Data",
        "semesters": [ "Autumn 2016" ],
        "institute": "ETH Zürich",
        "place": "Zürich, Switzerland",
        "image": "big-data.jpeg",
    },
    {
        "subject": "Network Security",
        "semesters": [ "Autumn 2015" ],
        "institute": "Aalto University",
        "place": "Espoo, Finland",
        "image": "network-security.jpeg",
    },
    {
        "subject": "Information Security",
        "semesters": [ "Autumn 2015" ],
        "institute": "Aalto University",
        "place": "Espoo, Finland",
        "image": "information-security.jpeg",
    }
]